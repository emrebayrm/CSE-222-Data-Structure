package Part2;

/**
 * Created by emre on 4/27/16.
 */
public class ResearchAsisstant {
    private String Name;
    private String Surname;
    private int AcademicBarcode;
    private int StudentBarcode;
    private int[] primesquence = {25,16,9,4,36};

    public ResearchAsisstant(String name, String surname, int studentBarcode, int academicBarcode) {
        Name = name;
        Surname = surname;
        AcademicBarcode = academicBarcode;
        StudentBarcode = studentBarcode;
    }

    /**
     * get Name
     * @return name
     */
    public String getName() {
        return Name;
    }

    /**
     * Sets name
     * @param name new name
     */
    public void setName(String name) {
        Name = name;
    }

    /**
     * get surname
     * @return surname
     */
    public String getSurname() {
        return Surname;
    }

    /**
     * sets new surname
     * @param surname  new surname
     */
    public void setSurname(String surname) {
        Surname = surname;
    }

    /**
     * academic Barcode Number
     * @return Barcode number
     */
    public int getAcademicBarcode() {
        return AcademicBarcode;
    }

    /**
     * new academic Barcode
     * @param academicBarcode new barcode number
     */
    public void setAcademicBarcode(int academicBarcode) {
        AcademicBarcode = academicBarcode;
    }

    /**
     * Student Barcode Number
     * @return student barcode number
     */
    public int getStudentBarcode() {
        return StudentBarcode;
    }

    /**
     * sets student barcode
     * @param studentBarcode
     */
    public void setStudentBarcode(int studentBarcode) {
        StudentBarcode = studentBarcode;
    }

    @Override
    public String toString() {
        return Name + " " +Surname + ' ' +AcademicBarcode + ' ' + StudentBarcode + '\n';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if(hashCode() == o.hashCode()) {
            if (((ResearchAsisstant) o).getAcademicBarcode() == this.getAcademicBarcode() &&
                    ((ResearchAsisstant) o).getStudentBarcode() == this.getStudentBarcode())
                return true;
            else return false;
        }
        else
            return false;
    }

    @Override
    public int hashCode() {
       /* char[] number = Integer.toString(AcademicBarcode).toCharArray();
        int res = 1;
        int res2 = 1;
        for (int i = 0; i < number.length; ++i)
            res += number[i] * primesquence[i];
        number = Integer.toString(StudentBarcode).toCharArray();
        for (int i = 0 ; i < number.length ; ++i)
            res2 += number[i] * primesquence[i];
        return (res * res2)/29;*/

        return 31 *( ( getAcademicBarcode() * 31) + getStudentBarcode() );
    }
}