package Part2;

import java.io.BufferedWriter;
import java.io.IOException;

/**
 * Created by emre on 4/27/16.
 */
public class StoreDataHashing implements IntStoreDataHashing {
    private ResearchAsisstant[] Data;
    private int tablesize;
    private int size;
    private int maxprobing;

    public StoreDataHashing() {
        tablesize = 2027; // 2027 is a prime number
        Data = new ResearchAsisstant[tablesize];
        size = 0;
    }

    /**
     * size of data
     * @return size
     */
    public int getSize() {
        return size;
    }

    /**
     * adds new element (quadratic probation)
     * @param element new element
     * @return adds new element if addiation is succesful return true
     * if it is already in data returns false and it doesn't add
     */
    public boolean addData(ResearchAsisstant element){
        if(size > tablesize * 0.6)
            ; // rehash
        int probing = 0;
        int index = element.hashCode()%tablesize;
        if(Data[index] == null)
        {
            ++size;
            Data[index] = element;
            return true;
        } else{
            do{
                if(element.equals(Data[index]))
                    return false;
                ++probing;
                index = (index * index) % tablesize;
            }while (Data[index] != null);
            Data[index] = element;
            ++size;
            if(maxprobing < probing)
                maxprobing = probing;
            return true;
        }
    }

    /**
     * removes the given data
     * NOTE : If deleted before again returns true
     * @param element will be removen element
     * @return true if deleted false if it is not in data
     */
    public boolean removeData(ResearchAsisstant element){
        int key = element.hashCode() % tablesize;
        if(Data[key] == null)
            return false;
        if(Data[key].getStudentBarcode() == element.getStudentBarcode() &&
                Data[key].getAcademicBarcode() == element.getStudentBarcode()){
            Data[key].setName("DELETED");
            Data[key].setSurname("DELETED");
            return true;
        }else{
            int i = 0;
            while (i <= maxprobing){
                key = (key * key ) % tablesize;
                if(Data[key] == null)
                    return false;
                else if(Data[key].equals(element)){
                    Data[key].setName("DELETED");
                    Data[key].setSurname("DELETED");
                    size--;
                    return true;
                }
                ++i;
            }
        }
        return false;
    }

    /**
     * return the given value's key value
     * @param value value
     * @return if value is not in the data returns -1
     */
    public int getKey(ResearchAsisstant value){
        int index = value.hashCode()%tablesize;
        if(Data[index] != null)
        {
            for(int i = 0; i < maxprobing; ++i)
                if(Data[index].equals(value))
                    return index;
                else
                    index = (index * index )% tablesize;
        }
        return -1;
    }

    /**
     * returns data according to key
     * @param key key value
     * @return
     */
    public ResearchAsisstant getData(int key){
        return Data[key];
    }

    /**
     * Prints Data's frequency
     */
    public void PrintAccumulationReport(){
        int freq = tablesize / 10;
        int counter = 0;
        int i;
        for ( i = 0; i < tablesize / freq ; ++i){
            for (int j = i * freq; j < i * freq + freq && j < tablesize; ++j){
                if(Data[j] != null && !Data[j].getName().equals("DELETED"))
                    ++counter;
            }
            System.out.println("there is " + counter +" elements  " +i*freq + "  between " + (i * freq + freq));
            counter = 0;
        }
        int k;
        for( k = i * freq; k < tablesize ; ++k)
            if(Data[k] != null && !Data[k].getName().equals("DELETED"))
                ++counter;
        System.out.println("there is " + (counter) +" elements " + (i *freq) + " between " + k);


    }

    /**
     * Writes All data to File with given writer
     * @param writer writer object
     * @throws IOException
     */
    public void WriteAllDatato(BufferedWriter writer) throws IOException {
        for (int i = 0,j = 1; i < tablesize; ++i){
            if(Data[i] == null)
                continue;
            writer.write(Integer.toString(j));
            writer.write(". ");
            writer.write(Data[i].toString());
            writer.flush();
            ++j;
        }
    }

}
