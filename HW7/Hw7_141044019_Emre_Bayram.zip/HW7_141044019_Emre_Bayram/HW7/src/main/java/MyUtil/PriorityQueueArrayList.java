package MyUtil;

/**
 * Created by emre on 4/25/16.
 */
import java.util.ArrayList;
import java.util.Comparator;
/**
 * It creates Priority queue with your comparator or it use class' comparaTo method
 * @param <E>
 */
public class PriorityQueueArrayList<E extends Comparable<E>> implements IntPriorityQueue<E>{
    private ArrayList<E> Data;
    private Comparator<E> comp = null;

    private void initializer(){
        Data = new ArrayList<E>();
    }

    public PriorityQueueArrayList(){
        initializer();
        comp = null;
    }

    public PriorityQueueArrayList(Comparator<E> comp)
    {
        initializer();
        this.comp = comp;
    }

    /**
     * Compares two object
     * @param left left operand
     * @param right right operand
     * @return returns if equal returns 0 if left bigger than right positive integer
     * otherwise return negative integer
     */
    private int compare(E left, E right)
    {
        if ( comp != null)
            return comp.compare(left,right);
        return left.compareTo(right);
    }
/*
    private void add(E element){
        data[(++end) % cap] = element;
    }

    private void add(int i,E element){
        for(int j = end; j != i; j-- ){
            if (j < 0)
                j = size;
            data[j+1] = data[j];
        }
        data[i] = element;
        end++;
    }


    private void reallocate(){
        E[] temp =(E[]) new Object[cap*2];
        for (int i= front,j=0 ; j < size; ++i, ++j)
        {
            temp[j] = data[i];
            i = (i + 1)%cap;
        }
        cap = cap*2;
        front = 0;
        end = size - 1;
        data = temp;
    }
*/
    public boolean enqueue(E element) {
  /*      if(cap == size +1){
            reallocate();
        }
*/
        try {
                int i = 0;
                boolean flag = false;
                while(!flag ){
                    if(i == Data.size())
                    {
                        flag = true;
                        Data.add(element);
                    }
                    else if(compare(element,Data.get(i)) > 0)
                    {
                        Data.add(i,element);
                        flag = true;
                    }
                    ++i;
                }
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }

    }

    public E dequeue() {
        if(Data.isEmpty())
            return null;
        return Data.remove(0);
    }

    public E peek() {
        if(Data.isEmpty())
            return null;
        return Data.get(0);
    }

    public E element() {
        return peek();
    }

    public boolean isEmpty() {
        return Data.isEmpty();
    }
}