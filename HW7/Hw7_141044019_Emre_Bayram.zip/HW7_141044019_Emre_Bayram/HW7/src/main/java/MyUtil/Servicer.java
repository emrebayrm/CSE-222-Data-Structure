package MyUtil;

/**
 * Created by emre on 4/25/16.
 */
public class Servicer {
    /*Variables for Servicer can be changeable*/
    public static int SERVICER_STARTWORK_TIME_HOUR = 8;
    public static int SERVICER_STARTWORK_TIME_MINUTE = 0;
    public static int SERVICER_ENDWORK_TIME_HOUR = 23;
    public static int SERVICER_ENDWORK_TIME_MINUTE = 59;

    private boolean isbusy;
    private int servecing;

    public Servicer(){
        isbusy = false;
        servecing = 0;
    }

    /**
     * Start serving
     * @param min service time in min
     */
    public void Serve(int min){
        isbusy = true;
        servecing = min;
    }

    /**
     * Checks the if it busy
     * @return true if busy else false
     */
    public boolean Isbusy()
    {
        if(servecing == 0)
            isbusy = false;
        return isbusy;
    }

    /**
     * it serves one minute (decrees a minute)
     */
    public void served(){
        if(servecing > 0)
            servecing--;
    }
}
