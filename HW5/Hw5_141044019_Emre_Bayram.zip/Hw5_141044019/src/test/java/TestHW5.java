/**
 * Created by emre on 3/31/16.
 */
public class TestHW5 {
    public static void main(String args[])
    {
        System.out.println("#####   Test Started !!!!");
        System.out.println("Testing Honoi tower");
        TestHonoi.Start();
        System.out.println("\n\nTesting Part2\n");
        TestPart2.Start();
        System.out.println("\n\nTesting Part3");
        TestPart3.Start();

        System.out.println("\n Test Finished !!!!!!");
    }
}
