package MyUtil;

import MyExceptions.WrongTimeException;
import org.jetbrains.annotations.NotNull;
/**
 * Created by emre on 4/25/16.
 */

/**
 * @author emre
 *
 */

/**
 * The Class Time.
 */
public class Time implements Comparable<Time>{

    /** The Hour. */
    private int Hour;

    /** The Minute. */
    private int Minute;


    /**
     * Create Time Object
     * @param hour
     * @param minute
     */
    public Time(int hour, int minute) {
        if(hour < 0 && hour > 24 && minute < 0 && minute > 60)
            throw new WrongTimeException("Check minute and Hour Values " +
                                            Integer.toString(hour) + "  " +
                                            Integer.toString(minute));
        Hour = hour;
        Minute = minute;
    }

    /**
     * Get Hour
     * @return
     */
    public int getHour() {
        return Hour;
    }

    /**
     * Set Hour
     * @param hour
     */
    public void setHour(int hour) {
        if(hour < 0 && hour > 24)
            throw  new WrongTimeException("Check Minute : " + Integer.toString(hour));
        Hour = hour;
    }

    /**
     * Get Minte
     * @return
     */
    public int getMinute() {
        return Minute;
    }

    /**
     * Set Minute
     * @param minute
     */
    public void setMinute(int minute) {
        if(minute < 0 && minute > 60)
            throw new WrongTimeException("Check Minute : " + Integer.toString(minute));
        Minute = minute;
    }

    public void addMinute(int min){
        int carry = (getMinute() + min) / 60;
        setMinute((getMinute() + min) % 60);
        setHour((getHour() + carry)%24);
    }

    public void addMinute()
    {
        int carry = (getMinute() + 1) / 60;
        setMinute((getMinute() + 1) % 60);
        setHour((getHour() + carry)%24);
    }

    public int differnce(Time t){
        return (this.getHour() - t.getHour()) * 60 + (this.getMinute() - t.getMinute());
    }

    /**
     * To String method
     * @return
     */
    @Override
    public String toString() {
        return ((getHour() < 10 ? "0" + getHour() : getHour()) + ":"
                + (getMinute() < 10 ? "0" + getMinute():getMinute() ));
    }

    public static String toString(int hour, int min){
        return ((hour < 10 ? "0" + hour : hour) + ":" + (min < 10 ? "0" + min:min ));
    }

    public int compareTo(@NotNull Time other) {
        if(getHour() > other.getHour() ||
                (getHour() == other.getHour() && getMinute() > other.getMinute()))
            return -1;
        if (getHour() == other.getHour() && getMinute() == other.getMinute())
            return 0;
        return 1;
    }
}