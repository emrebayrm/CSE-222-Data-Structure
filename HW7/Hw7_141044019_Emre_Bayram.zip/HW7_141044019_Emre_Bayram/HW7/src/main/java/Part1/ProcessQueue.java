package Part1;


import MyUtil.*;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.util.*;

/**
 * Created by emre on 4/25/16.
 */
public class ProcessQueue implements IntProcessQueue {

    private BufferedReader reader;      // Reader for reading in file
    private ArrayList<Customer> queue;  // readed data
    private Servicer servicer;          // Service worker
    private BufferedWriter writer;      // to write result
    private int goldcust =0 ,
            silvercust = 0,
            bronzcust = 0;

    /**
     * Constructor
     * @param filename input filename
     */
    public ProcessQueue(String filename)
    {
        try {
            reader = new BufferedReader(new FileReader(filename));
        } catch (FileNotFoundException e) {
            //TODO
        }
        servicer = new Servicer();
        queue = new ArrayList<Customer>();

        try {
            writer = new BufferedWriter(new FileWriter("ProccessedQueue.txt"));
            writer.write("Arrived\tServed At \t Service Time \t Customer Type\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*Algorithm
    queue da bekleyen var mı ?
            var
                service meşgul mü ?
                    hayır değil
                        serve et
                        queue dan çıkar
                    endif
                        meşgulse yapıcak bişey yok
    biri geldi mi ?
        geldi then
            servicer meşgul mü ?
                evet meşgul
                 waiter queue ya priorirty e göre queue ya ekle
            end if
            hayır meşgul değil
                o customer a serve et
            end else

    bir dakika ekle
    */

    /**
     * Runs simulation with DEFAULT SERVICER VALUES
     * At the end writes to results to TestResult.txt
     */
    public void Proccess(){
        this.Proccess(Servicer.SERVICER_STARTWORK_TIME_HOUR,Servicer.SERVICER_STARTWORK_TIME_MINUTE,
                Servicer.SERVICER_ENDWORK_TIME_HOUR,Servicer.SERVICER_ENDWORK_TIME_MINUTE);
    }

    /**
     * Runs simulation  At the end writes to results to TestResult.txt
     * @param starthour servicer start time hour
     * @param startmin  servicer start time minure
     * @param endhour   servicer end time hour
     * @param endmin    servicer end time minute
     */
    public void Proccess(int starthour, int startmin, int endhour, int endmin){
        Time time = new Time(starthour,startmin);
        Time startTime = new Time(starthour,startmin);
        Time endtime = new Time (endhour,endmin);

        Customer customer;
        PriorityQueueArrayList<Customer> waiterqueue = new PriorityQueueArrayList<Customer>();
        this.generatequeue();
        while(!queue.isEmpty() || !servicer.Isbusy() || !waiterqueue.isEmpty())
        {
            if (!waiterqueue.isEmpty() && !servicer.Isbusy()){
                customer = waiterqueue.dequeue();
                WriteQueue(customer,time);
                servicer.Serve(customer.getServiceTime());
                Counter(customer.getPriority());
            }
            customer = isAnArrival(time);
            if(customer != null) {
                if (servicer.Isbusy()) {
                    waiterqueue.enqueue(customer);
                } else {
                    servicer.Serve(customer.getServiceTime());
                    Counter(customer.getPriority());
                    WriteQueue(customer,time);
                }
            }
            servicer.served();

            if(time.differnce(startTime) == 20*60 )
            {
                System.out.println("SERVED To GOLD CUSTOMER  > " + goldcust);
                System.out.println("SERVED To SILVER CUSTOMER  > " + silvercust);
                System.out.println("SERVED To BRONZ CUSTOMER  > " + bronzcust);
                System.out.println("                    UNTIL NOW > " + time.toString());
            }
            time.addMinute();
        }

        try {

            writer.newLine();
            writer.write("<<<  AT THE END OF DATA  >>> \n");
            writer.write("SERVED To GOLD CUSTOMER  > " + goldcust + '\n');
            writer.write("SERVED To SILVER CUSTOMER  > " + silvercust + '\n');
            writer.write("SERVED To BRONZ CUSTOMER  > " + bronzcust + '\n');
            writer.write("                       TIME > " + time.toString() + '\n');
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Line parser
     * @param line line
     * @return Integer array
     */
    private Integer[] Parser(String line){
        char arr[] = line.toCharArray();
        Integer retarr[] = new Integer[arr.length];
        char val[] = new char[2];
        boolean flag = false;
        int k = 0;

        for (int i = 0; i < arr.length; ++i)
        {
            for(int j = 0 ;j < val.length &&i < arr.length && arr[i] >= '0' && arr[i] <= '9'; ++i,++j)
            {
                val[j] = arr[i];
                flag = true;
            }
            if(flag){
                if(arr.length == i)
                {
                    val[1] = val[0];
                    val[0] = '0';
                }
                flag = false;
                retarr[k] = Integer.parseInt(String.valueOf(val));
                ++k;
            }
        }

        return retarr;
    }

    /**
     * reads the input file
     */
    private void generatequeue(){
        String line;
        Scanner scanner;
        scanner = new Scanner(reader);
        Integer integer[];
        scanner.nextLine();
        while (scanner.hasNext()){
            line = scanner.nextLine();
            integer = Parser(line);
            queue.add(new Customer(integer[0],integer[1],integer[2],integer[3]));
        }

    }

    /**
     * checks any arrived Customer according to input file
     * @param time
     * @return if any arrival at that time returns it but if no arrival returns null
     */
    @Nullable
    private Customer isAnArrival(Time time){
        if(queue.isEmpty())
            return null;
        if(time.compareTo(queue.get(0).getArrivalTime()) <= 0)
        {
            return queue.remove(0);
        }
        return null;
    }

    /**
     * Writes the result at the time
     * @param customer
     * @param serveTime
     */
    private void WriteQueue(Customer customer,Time serveTime){
        String str = Time.toString(customer.getHour(),customer.getMinute()) +" ->  " +serveTime.toString() + " \t\tserved\t"
                + (customer.getServiceTime() < 10 ? "0" + customer.getServiceTime() : customer.getServiceTime() ) + "\t\t"
                + "Customer " + (customer.getPriority()) + "\n";
        try {
            writer.write(str);
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * counts that served customer
     * @param priority
     */
    private void Counter(int priority){
        switch (priority){
            case 1:
                goldcust++;
                break;
            case 2:
                silvercust++;
                break;
            case 3:
                bronzcust++;
                break;
        }
    }
}