package MyUtil;

import org.jetbrains.annotations.NotNull;

/**
 * Created by emre on 4/25/16.
 */
public class Customer implements Comparable<Customer>{



    private Time arrivalTime;
    private int serviceTime;
    private int priority;

    public Customer(int arrhour , int arrmin, int serviceTime, int priority) {
        try{
            arrivalTime = new Time(arrhour,arrmin);
        }catch (Exception ex)
        {
            System.out.println("Time Values are Wrong " + ex.getMessage());
        }
        this.serviceTime = serviceTime;
        this.priority = priority;
    }

    public Time getArrivalTime() {
        return arrivalTime;
    }

    public int getHour(){
        return arrivalTime.getHour();
    }
    /* GETTERS and SETTERS*/
    public int getMinute(){
        return arrivalTime.getMinute();
    }

    public void setHour(int Hour){
        arrivalTime.setHour(Hour);
    }

    public void setMinute(int minute) {
        arrivalTime.setHour(minute);
    }

    public int getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(int serviceTime) {
        this.serviceTime = serviceTime;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
    /* END of GETTER and SETTERS*/
    /**
     * Compares Two Customer's priorities
     * @param t gonna compare customer
     * @return if this object's priority is bigger than parameter returns -1
     * if they priority are equal returns 0
     * if parameter's priority is bigger returns 1
     */
    public int compareTo(@NotNull Customer t) {
        if(getPriority() < t.getPriority())
            return 1;
        if(getPriority() == t.getPriority())
            return 0;
        return -1;
    }
}
