package Part1;

import java.io.Serializable;

/**
 * Created by emre on 4/28/16.
 */
public interface IntProcessQueue extends Serializable {
    void Proccess();

    void Proccess(int starthour, int startmin, int endhour, int endmin);
}
