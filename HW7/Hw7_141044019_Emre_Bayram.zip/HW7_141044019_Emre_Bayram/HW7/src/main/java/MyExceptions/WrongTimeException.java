package MyExceptions;

/**
 * Created by emre on 4/25/16.
 */
public class WrongTimeException extends RuntimeException {

    public WrongTimeException(String message)
    {
        super(message);
    }

}