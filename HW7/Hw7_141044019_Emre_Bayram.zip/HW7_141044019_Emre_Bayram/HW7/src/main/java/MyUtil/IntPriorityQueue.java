package MyUtil;

/**
 * Created by emre on 4/25/16.
 */
public interface IntPriorityQueue <E extends Comparable <E>> {
        /**
         * Adds New Element to Queue
         * @param element eleman
         * @return returns true or false
         */
        boolean enqueue(E element);

        /**
         * it pulls in front of queue
         * @return  returns removed elem
         */
        E dequeue();

        /**
         * At the top of elem actually in front of queue
         * @return returns in front of queue
         */
        E peek();

        /**
         * Same as peek
         * @return peek()
         */
        E element();

        boolean isEmpty();
}
