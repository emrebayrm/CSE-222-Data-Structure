import Part1.IntProcessQueue;
import Part1.ProcessQueue;
import Part2.ResearchAsisstant;
import Part2.StoreDataHashing;

import java.io.*;

/**
 * Created by emre on 4/26/16.
 */
public class Tests {
    public static void main(String[] argv){
        System.out.println("\t\t\t\t Part1 Test Section \n");
        System.out.println("If you want change start and end time of Servicer Worker");
        System.out.println("And you can change Input file.");
        IntProcessQueue test = new ProcessQueue("data2.txt");
        test.Proccess(0,1,23,59);
        System.out.println("There is report as file in ProcessedQueue.txt");
        System.out.println("End Of Part1 Testing");

        System.out.println();
        System.out.println("\t\t\t\t Part2 Test Section ");
        System.out.println("There is a Data set Randomly created Named Part2DataSet.txt\n");
        BufferedReader reader;
        BufferedWriter writer;
        StoreDataHashing test2 = new StoreDataHashing();
        try {
            reader = new BufferedReader(new FileReader("DataSet.txt"));
            String line;
            String parsed[];
            int i = 0;
            int sameelement = 0;
            while ((line = reader.readLine()) != null) {
                parsed = line.split("[ ]+");
                if (!test2.addData(new ResearchAsisstant(parsed[0], parsed[1],
                        Integer.parseInt(parsed[2]),
                        Integer.parseInt(parsed[3])))) {
                    ++sameelement;
                }else
                    ++i;
            }

            System.out.println("\nEnd Of addition Data as a result : ");
            System.out.println("Data added : " + i);
            System.out.println("Data Not added : " + sameelement);
            System.out.println("in Data set first three item repeated intentionaly 500 - 3 = 497 " );
            System.out.println("i should 497 and sameelement counter should 3 " );
            System.out.println("i : " + i +(i == 497 ? " PASSED" : " FAILED"));
            System.out.println("sameelement : " + sameelement + (sameelement == 3 ? " PASSED ": " FAILED"));

            System.out.println("\nTesting equality");
            ResearchAsisstant testtoequal = new ResearchAsisstant("Howard","Wolfe",2674,9097); //from my data set
            if(testtoequal.equals(test2.getData(test2.getKey(testtoequal)))) {
                System.out.println("There is no Error they same person ");
            }
            else{
                System.out.println("There is an Error They should be equal");
            }

            System.out.println("\nCase 1: delete an entry that is not data");
            System.out.println("remove method should return false");
            testtoequal = new ResearchAsisstant("Emre","Bayram",1410,9401); // there isn't in data set

            System.out.println("Ret val of remove() : " + (test2.removeData(testtoequal) ? "true FAILED" : "false PASSED"));
            System.out.println("\nCase 2 : delete something in data");
            ResearchAsisstant delete = new ResearchAsisstant("Howard","Wolfe",2674,9097); // choosen in data set
            System.out.println("Ret Val of remove() : " + (test2.removeData(delete) ? "true PASSED ": "false FAILED"));

            System.out.println("\nCase 3 : delete entry deleted before "); // same deletion
            System.out.println("Ret Val of remove() : " + (test2.removeData(delete) ? "true PASSED ": "false FAILED"));

            System.out.println("\nCase 4 : delete that isn't in data but same barcode numbers ");
            delete = new ResearchAsisstant("Emre","Bayram",4289,6052); // choosen in data set Belong to > Lisa Ramos
            System.out.println("Ret Val of remove() : " + (test2.removeData(delete) ? "true FAILED ": "false PASSED"));

            System.out.println("\nAccumulation Report > \n");
            test2.PrintAccumulationReport();
            System.out.println("\nThere is a normal Accumlation ");

            writer = new BufferedWriter(new FileWriter("TestResult.txt"));
            test2.WriteAllDatato(writer);
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found :" + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
