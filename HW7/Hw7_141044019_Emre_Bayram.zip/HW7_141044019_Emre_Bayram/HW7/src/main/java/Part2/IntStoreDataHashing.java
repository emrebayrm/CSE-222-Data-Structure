package Part2;

/**
 * Created by emre on 4/27/16.
 */
public interface IntStoreDataHashing {

    /**
     * Size of Table
     * @return size
     */
    int getSize();

    /**
     * Adds New Data to Table
     * @param element new element
     * @return true or false whether the added succesfully or not
     */
    boolean addData(ResearchAsisstant element);

    /**
     * Removes the Given data is in the Table
     * @param element will be removen element
     * @return true or false whether the removed succesfullt or not
     */
    boolean removeData(ResearchAsisstant element);

    /**
     * Returns the given value's Key value's
     * @param value value
     * @return key value
     */
    int getKey(ResearchAsisstant value);

    /**
     * Gets data the given key value
     * @param key key value
     * @return data
     */
    ResearchAsisstant getData(int key);


}
